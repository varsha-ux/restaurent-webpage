 $(document).ready(function(){


	$(".counterup-text span").counterUp({
		delay: 1,
		time: 200
	});
});
