const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session') ;
const mongoose = require('mongoose');

//Connect to mongo database
mongoose.connect('mongodb://localhost:27017/reswebDB', {
  useNewUrlParser: true,useUnifiedTopology:true
});

//Define a schema
var bookSchema = new mongoose.Schema({
  name: String,
  email:String,
  date: { type: Date, default:new Date()},
  time: String,
  people: Number
});

var userSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String
});



//Create a model
var Book = mongoose.model('Book', bookSchema);
var User = mongoose.model('User', userSchema);


// express setup
const app = express();

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));
app.use(session({ secret: 'super secret' , resave: true,
    saveUninitialized: true}));

var book=[];
var user=[];

//Routes
app.get('/',function(req,res){

 res.render('index');
});





app.get('/status',function(req,res){

    Book.find({email:req.session.email},function(err,book){
      console.log(" print status");
     res.render('status',{book:book});
      });
});

app.post('/menu', function(req, res) {

//check which user is logged inspect
//get that user's name and email
 var uname =req.session.username;
 var uemail =req.session.email;

  var book = new Book({

    //user: //_id from users collection
    name: uname,
    email:uemail,
    date: req.body.date,
    time: req.body.time,
    people: req.body.people,
  });

  book = book.save();

req.session.email=uemail;
  res.redirect('/status');
});





app.post('/login', function(req, res) {
  var password = req.body.password;
  User.findOne({
    username: req.body.username
  }, function(err, foundUser) {
    if (err) {
      console.log(err);
    } else {
      try {
        if (foundUser.password === password) {
          req.session.email= req.body.email;
          req.session.username= req.body.username;
          res.redirect('/menu');
        }
      } catch {
          res.redirect("/register");


      }
    }
  });
});









app.get('/menu',function(req,res){

 res.render('menu');
});

app.get('/contact',function(req,res){

 res.render('contact');
});

app.get('/about',function(req,res){

 res.render('about');
});

app.get('/login',function(req,res){

 res.render('login');
});


app.get('/register',function(req,res){

 res.render('register');
});
app.post('/register', function(req, res) {
  var user = new User({
    username: req.body.username,
    email: req.body.email,
    password: req.body.password
  });
  user.save();
  req.session.email=req.body.email;
  req.session.username=req.body.username;

  res.redirect('/menu');
});






app.get('/confirm',function(req,res){

 res.render('confirm');
});












app.listen(3000, function() {
  console.log("Server running on port 3000");
});
